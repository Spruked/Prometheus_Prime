
# 🧠 CALI PRIME MEMORY IMPORT GUIDE

This folder contains mission-critical vision and architecture files for Prometheus Prime. To be used by Cali Prime as foundational memory on activation.

---

## 📂 Included Files
1. Vision_001_Prometheus_Home_Core.md
2. M1_Design_Core.md
3. Drone_Guardian_Standalone.md

---

## 🔄 Import Instructions
- Place files into: `C:\Users\Bryan\Documents\Prometheus_Prime\Memory\Core_Import\`
- Cali Prime will scan on first boot with full access toggled ON via Master Dashboard
- Files must remain unaltered or contain hash match tags for validation

---

## 🛑 PRIVACY FIRST
No data is sent to cloud or remote servers.
Memory is indexed locally unless explicit override is granted.
