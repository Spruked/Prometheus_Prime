from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/")
def index():
    return jsonify({"status": "Prometheus Core Engine is active."})

@app.route("/echo", methods=["POST"])
def echo():
    data = request.json
    return jsonify({
        "received": data,
        "response": f"Echo processed: {data.get('message', 'No message provided')}"
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
